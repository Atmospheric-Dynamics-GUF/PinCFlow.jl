import numpy
import numpy.fft as fft
import tools
import style
import matplotlib.pyplot as pyplot

# Import data.
data = tools.ModelOutput()
data.import_data("../barLC/")
reference = tools.ModelOutput()
reference.import_data("../../../pincflow/tests/barLC/")

# Adust coordinate unit.
data.xx *= 0.001
data.yy *= 0.001

# Set fields of indices.
iz = 22
it = - 1

# Print time.
print(" ".join(("Time:", str(data.tt[it]), "s")))

# Loop over data and reference.
for set in (reference, data):

    # Set fields of interest.
    rho = set.psi[it, 0, iz, int(0.5 * set.ny):set.ny, :]
    uu = set.psi[it, 1, iz, int(0.5 * set.ny):set.ny, :]
    vv = set.psi[it, 2, iz, int(0.5 * set.ny):set.ny, :]
    ww = set.psi[it, 3, iz, int(0.5 * set.ny):set.ny, :]
    pi = set.psi[it, 4, iz, int(0.5 * data.ny):set.ny, :]
    rhop = set.psi[it, 5, 0, int(0.5 * set.ny):set.ny, :]

    # Compute divergence.
    divergence = numpy.zeros_like(uu)
    divergence[1:, 1:] = (uu[1:, 1:] - uu[1:, :(- 1)]) / set.dx + (vv[1:, 1:]
            - vv[:(- 1), 1:]) / set.dy

    # Apply Fourier filter.
    urossby = numpy.zeros_like(uu)
    ugravity = numpy.zeros_like(uu)
    sigma = divergence
    sigmatilde = fft.fft2(sigma)
    kk = fft.fftfreq(sigma.shape[1], d = set.dx)
    ll = fft.fftfreq(sigma.shape[0], d = set.dy)
    urossbytilde = sigmatilde.copy()
    urossbytilde[numpy.abs(ll) > 1.0E-6, :] = 0.0
    urossbytilde[:, numpy.abs(kk) > 1.0E-6] = 0.0
    urossby = fft.ifft2(urossbytilde).real
    ugravity = sigma - urossby

    # Compute differences of relevant fields.
    if set == reference:
        deltaugravity = ugravity.copy()
        deltau = uu.copy()
        deltav = vv.copy()
        deltarhop = rhop.copy()
    elif set == data:
        deltaugravity = ugravity - deltaugravity
        deltau = uu - deltau
        deltav = vv - deltav
        deltarhop = rhop - deltarhop

# Adjust plotting area.
data.xx = data.xx[iz, int(0.5 * data.ny):data.ny, :]
data.yy = data.yy[iz, int(0.5 * data.ny):data.ny, :]

# Make plot.
peak = numpy.max(numpy.abs(ugravity))
rhopmax = numpy.max(numpy.abs(rhop))
figure, axes = pyplot.subplots()
plot = axes.pcolormesh(data.xx, data.yy, ugravity, vmax = peak, vmin = - peak,
        shading = "gouraud", cmap = "seismic")
axes.quiver(data.xx[::10, ::10], data.yy[::10, ::10], uu[::10, ::10],
        vv[::10, ::10], width = 0.01, scale = 500)
axes.contour(data.xx, data.yy, rhop,
        linewidths = 1.0, colors = "black")
axes.set_xlabel(r"$x \, \left[\mathrm{km}\right]$")
axes.set_ylabel(r"$y \, \left[\mathrm{km}\right]$")
figure.colorbar(plot, label = r"$\boldsymbol{\nabla}_z \cdot"
        r"\boldsymbol{u} \, \left[\mathrm{s^{- 1}}\right]$")
figure.savefig("../results/barLC.pdf")
figure.savefig("../results/barLC.png")

# Make difference plot.
peak = numpy.max(numpy.abs(deltaugravity))
rhopmax = numpy.max(numpy.abs(deltarhop))
figure, axes = pyplot.subplots()
plot = axes.pcolormesh(data.xx, data.yy, deltaugravity, vmax = peak,
        vmin = - peak, shading = "gouraud", cmap = "seismic")
axes.quiver(data.xx[::10, ::10], data.yy[::10, ::10], deltau[::10, ::10],
        deltav[::10, ::10], width = 0.01, scale = 500)
axes.contour(data.xx, data.yy, deltarhop,
        linewidths = 1.0, colors = "black")
axes.set_xlabel(r"$x \, \left[\mathrm{km}\right]$")
axes.set_ylabel(r"$y \, \left[\mathrm{km}\right]$")
figure.colorbar(plot, label = r"$\Delta \boldsymbol{\nabla}_z \cdot"
        r"\boldsymbol{u} \, \left[\mathrm{s^{- 1}}\right]$")
figure.savefig("../results/barLC_difference.pdf")
figure.savefig("../results/barLC_difference.png")
